// function updateColor() {
//     var isChecked = document.getElementById("time_switch").checked;
//     var box = document.getElementById("time_box");
//     if (isChecked == true) {
//         if(conflict == true){
//             box.style.backgroundColor = "#ff7770";
//         }
//         if(conflict == false) {
//             box.style.backgroundColor = "#42d67b";
//         }
//         if(conflict == "") {
//             box.style.backgroundColor = "#3250a8";
//         }
//     }
//     else{
//         box.style.backgroundColor = "#3250a8";
//     }
// }